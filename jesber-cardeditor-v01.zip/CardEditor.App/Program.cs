﻿using System;
using CardEditor.Domain;
using Data;
using MongoDB.Driver;

namespace CardEditor.App
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
